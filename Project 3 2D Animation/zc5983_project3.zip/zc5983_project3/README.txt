<project3> Report for <zc5983>
====================================

## Instructions

<Run Information_Extractors.py to extract the text from source.txt. Then open zc5983_project2 in Processing and click Run. Press 's' to switch between display modes. Left click to change different portion of the text.>

## Report

<Implemented all required features. I asked Chatgpt for debugging my code and instructing me how to implement functions not covered in class.
The narrative of your animation: birds flying across a forest.
What the included classes do: Bird class create birds.  
			      FlappingBird gives the wing flapping animation, along with varying velocity and flying direction. 
			      Tree class create the trunk of the trees.
			      Leaf class create leaves with animation and varying colors. 
How you met the two-transformation requirement: The birds both move (translate) and the wings flap (rotate). 
						The trees shakes (rotate, scale).
Your two classes and what members they have: The Tree class has the Leaf subclass; the Bird class has the FlappingBird subclass. 
How you met the two-instance requirement: The tree leaves have different colors and rotation directions. 
					  The birds have different velocity and flying direction.
Any unexpected challenges you faced along the way: I did not know how to group objects using PShape, so I asked Chatgpt for assistence. >