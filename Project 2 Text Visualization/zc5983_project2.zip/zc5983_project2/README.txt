<project2> Report for <zc5983>
====================================

## Instructions

<Run Information_Extractors.py to extract the text from source.txt. Then open zc5983_project2 in Processing and click Run. Press 's' to switch between display modes. Left click to change different portion of the text.>

## Report

<Implemented all required features. I asked Chatgpt to debug my code.>