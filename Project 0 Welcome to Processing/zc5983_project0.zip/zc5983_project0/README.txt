<project0> Report for <zc5983>
====================================

## Instructions

<Open the file in Processing and click Run. Press 'S' to change the display mode.>

## Report

<Implemented all required features. Some of the code for visualizing distance are inspired, but not copied, from ChatGPT.>