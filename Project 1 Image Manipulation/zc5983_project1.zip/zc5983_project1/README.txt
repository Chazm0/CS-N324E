<project1> Report for <zc5983>
====================================

## Instructions

<Open the file in Processing and click Run. 
 Press 0 to reset.
 Press 1 to Grayscale.
 Press 2 to Contrast.
 Press 3 to Gaussian Blur.
 Press 4 to Detect Edge.>

## Report

<Implemented all required features.Some of the code for Edge Detection are inspired, but not copied, from ChatGPT.>